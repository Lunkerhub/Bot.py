# AI Telegram Bot с Системой Подписок

## Overview
Telegram бот с искусственным интеллектом на базе Google Gemini 2.0 через OpenRouter API. Включает полноценную систему подписок с учётом пользователей и лимитами запросов.

**Статус:** Полностью функционален ✅

## Project Architecture
- **Language**: Python 3.12
- **Main Files**: 
  - `Bot.py` - Основной код бота
  - `database.py` - Система подписок и база данных
  - `users.db` - SQLite база пользователей (создаётся автоматически)
- **Key Dependencies**:
  - `python-telegram-bot`: Telegram bot framework
  - `requests`: HTTP library для API запросов
  - `sqlite3`: База данных
  
## Features
- 🤖 AI ответы на базе Google Gemini 2.0
- 💎 Система подписок: FREE (20/день), VIP (100/день), PREMIUM (500/день)
- 👑 Безлимитный доступ для владельца @Honorpadx9lte
- 📊 Учёт запросов для каждого пользователя
- 🗄️ Автоматическое создание аккаунтов
- 📈 Статистика использования
- 🔄 Автоматический сброс лимитов каждый день
- `/start` - Приветствие и статистика
- `/status` - Проверить свои лимиты
- `/subscription` - Информация о подписках

## Environment Variables
Required secrets:
- `BOT_TOKEN`: Telegram Bot API token
- `OPENROUTER_API_KEY`: OpenRouter API key for DeepSeek access

## Setup
1. Set up the required environment variables (BOT_TOKEN and OPENROUTER_API_KEY)
2. Run `python Bot.py` to start the bot

## Recent Changes
- 2025-11-14: Полная настройка и запуск
  - Импорт проекта из GitHub
  - Миграция на безопасное хранение API ключей (environment variables)
  - Установка зависимостей (python-telegram-bot, requests)
  - Исправление конфликтов пакетов
  - Переход с DeepSeek на Google Gemini 2.0
  - **Внедрена система подписок:**
    - Создана база данных SQLite
    - Реализованы 4 уровня подписок (FREE/VIP/PREMIUM/ADMIN)
    - Автоматический учёт запросов
    - Владелец получает безлимитный доступ
    - Команды /status и /subscription
  - Бот работает стабильно
